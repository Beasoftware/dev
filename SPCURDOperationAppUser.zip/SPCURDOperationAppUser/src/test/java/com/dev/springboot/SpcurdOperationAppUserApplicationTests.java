package com.dev.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpcurdOperationAppUserApplicationTests {

	@Test
	void contextLoads() {
	}

}
