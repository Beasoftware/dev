package com.dev.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SpcurdOperationAppUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpcurdOperationAppUserApplication.class, args);
	}

}
